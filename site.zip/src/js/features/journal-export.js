import { dayKey } from '../core/clock.js';
import { promptById } from './prompts.js';

/**
 * "Copy" and "Save as .txt" for the mind dump (and for archived nights), so a page can be
 * kept before the midnight clear without turning on the archive.
 */
const longDate = (day) => {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
};

export function formatPage({ text, day = dayKey(), prompt = null }) {
  const lines = ['Digital Sunset · Mind dump', longDate(day), ''];
  if (prompt) lines.push(`Tonight’s prompt: ${prompt}`, '');
  lines.push(text.trim(), '', '— Saved from Digital Sunset by Fête Studio Events. Everything stays on your device.');
  return `${lines.join('\n')}\n`;
}

export const pageFromJournal = (journal) => ({
  text: journal.text,
  day: journal.day ?? dayKey(),
  prompt: promptById(journal.promptId)?.text ?? null,
});

export const fileName = (day) => `mind-dump-${day}.txt`;

/** Copies text to the clipboard. Resolves true on success. */
export async function copyText(text) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fall through to the legacy path (older iOS, permission quirks).
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none';
  document.body.append(area);
  area.select();
  area.setSelectionRange(0, text.length);
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {
    ok = false;
  }
  area.remove();
  return ok;
}

/**
 * Saves text as a .txt file. On phones, the share sheet ("Save to Files", Notes, AirDrop…)
 * is the dependable route, especially inside an installed iPhone app; elsewhere it downloads.
 * Resolves 'shared' | 'downloaded' | 'cancelled'.
 */
export async function saveTextFile(text, name) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const coarse = window.matchMedia?.('(pointer: coarse)').matches;
  if (coarse && typeof File === 'function' && navigator.canShare) {
    const file = new File([blob], name, { type: 'text/plain' });
    if (navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: name });
        return 'shared';
      } catch (err) {
        if (err?.name === 'AbortError') return 'cancelled';
        // Any other failure: fall back to a plain download.
      }
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  return 'downloaded';
}
