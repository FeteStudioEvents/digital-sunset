/**
 * Ambient sound engine. Every sound is synthesized with the Web Audio API
 * from generated noise buffers, so there are no audio files to download or cache.
 *
 * Graph: voice sources → filters → voice gain (fade in/out) → layer level → master gain → speakers
 *
 * iPhone/iPad notes
 * - Audio may only start inside a tap. installAudioUnlock() resumes (or creates) the
 *   AudioContext on the first touch/click/key anywhere and plays one silent sample, the
 *   long-standing WebKit unlock. It re-arms itself if iOS suspends or "interrupts" the
 *   context later (phone call, Siri, lock screen), so the next tap brings sound back.
 * - Where supported (Safari 17+), the audio session is set to "playback" while a sound
 *   plays, so the ring/silent switch doesn't mute an ambience the user chose.
 */

const SOUNDS = {
  brown: { label: 'Brown noise', note: 'A deep, steady hush', build: buildBrown },
  rain: { label: 'Rain', note: 'Soft rain on glass', build: buildRain },
  cabin: { label: 'Forest cabin', note: 'Hearth and pine wind', build: buildCabin },
};

export const SOUND_LIST = Object.entries(SOUNDS).map(([id, { label, note }]) => ({ id, label, note }));

let ctx = null;
let master = null;
let volume = 0.7;
let fadeTimer = null;
const levels = { brown: 0.7, rain: 0.7, cabin: 0.7 };
const voices = new Map();
const buffers = {};
const listeners = new Set();

/** Subscribe to the set of playing sound ids. Returns an unsubscribe function. */
export function onChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

const emit = () => listeners.forEach((fn) => fn(new Set(voices.keys())));

export const isPlaying = (id) => voices.has(id);

export function toggle(id) {
  if (voices.has(id)) stop(id);
  else play(id);
}

export function play(id) {
  if (voices.has(id) || !SOUNDS[id]) return;
  const ac = context();
  if (!ac) return;

  // Cancel any end-of-ritual fade: picking a sound means the listener wants it.
  clearTimeout(fadeTimer);
  rampTo(master.gain, volume, 0.1);

  setAudioSession('playback');
  const level = gain(ac, levels[id] ?? 0.7);
  level.connect(master);
  const out = ac.createGain();
  out.gain.value = 0;
  out.connect(level);
  const nodes = SOUNDS[id].build(ac, out);
  rampTo(out.gain, 1, 0.6);

  voices.set(id, { out, level, nodes });
  emit();
}

export function stop(id) {
  const voice = voices.get(id);
  if (!voice) return;
  voices.delete(id);
  rampTo(voice.out.gain, 0, 0.3);
  setTimeout(() => {
    voice.nodes.forEach((node) => node.stop());
    voice.out.disconnect();
    voice.level.disconnect();
    if (voices.size === 0) setAudioSession('auto');
  }, 2000);
  emit();
}

const clamp01 = (value) => Math.min(1, Math.max(0, Number(value) || 0));

/** Master volume (the slider beside Ambience). */
export function setVolume(value) {
  volume = clamp01(value);
  if (master) rampTo(master.gain, volume, 0.05);
}

/** Per-layer level (Settings → Sound levels). Applies live to a playing layer. */
export function setLayerVolume(id, value) {
  if (!(id in levels)) return;
  levels[id] = clamp01(value);
  const voice = voices.get(id);
  if (voice && ctx) rampTo(voice.level.gain, levels[id], 0.05);
}

export function setLayerVolumes(map = {}) {
  Object.entries(map).forEach(([id, v]) => setLayerVolume(id, v));
}

export const layerVolume = (id) => levels[id];

/** Stops everything immediately (used by "Reset app data"). */
export function stopAll() {
  clearTimeout(fadeTimer);
  [...voices.keys()].forEach(stop);
}

/**
 * Unlocks audio on the first user gesture (required by iOS Safari and by Chrome's
 * autoplay policy). Safe to call more than once; listeners remove themselves once
 * the context is running and re-arm if it is later suspended or interrupted.
 */
export function installAudioUnlock(target = document) {
  const events = ['touchend', 'pointerdown', 'click', 'keydown'];
  let armed = false;

  const unlock = () => {
    const ac = context();
    if (!ac) return disarm();
    try {
      // A one-sample silent buffer started inside the gesture fully unlocks older WebKit.
      const src = ac.createBufferSource();
      src.buffer = ac.createBuffer(1, 1, ac.sampleRate);
      src.connect(ac.destination);
      src.start(0);
    } catch {
      // Ignore: resume() below is the part that matters on current browsers.
    }
    const done = () => { if (ac.state === 'running') disarm(); };
    const resumed = ac.state === 'running' ? null : ac.resume?.();
    if (resumed?.then) resumed.then(done, () => {});
    else done();
  };

  function arm() {
    if (armed) return;
    armed = true;
    events.forEach((type) => target.addEventListener(type, unlock, { capture: true, passive: true }));
  }
  function disarm() {
    armed = false;
    events.forEach((type) => target.removeEventListener(type, unlock, { capture: true }));
  }

  arm();
  // iOS suspends or "interrupts" audio when the app is backgrounded; bring it back on return.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible' || !ctx) return;
    if (ctx.state !== 'running') {
      ctx.resume?.().catch(() => {});
      arm();
    }
  });
  return disarm;
}

/** State of the audio engine, for diagnostics and tests. */
export const audioState = () => ctx?.state ?? 'none';

/** Slowly fades everything to silence, then stops all voices. */
export function fadeOutAll(seconds) {
  if (!master || voices.size === 0) return;
  rampTo(master.gain, 0, seconds / 5);
  clearTimeout(fadeTimer);
  fadeTimer = setTimeout(() => [...voices.keys()].forEach(stop), seconds * 1000);
}

/** A soft two-partial bell, used to mark the end of the ritual. */
export function chime() {
  // Never create a context outside a tap (browsers block it and log a warning);
  // the audio unlock creates one on the first touch, so this is normally ready.
  if (!ctx) return;
  const ac = context();
  const t = ac.currentTime + 0.05;
  [[396, 0.12], [594, 0.05], [792, 0.03]].forEach(([freq, level]) => {
    const osc = ac.createOscillator();
    const env = ac.createGain();
    osc.frequency.value = freq;
    env.gain.setValueAtTime(0, t);
    env.gain.linearRampToValueAtTime(level, t + 0.02);
    env.gain.exponentialRampToValueAtTime(0.0001, t + 5);
    osc.connect(env).connect(ac.destination);
    osc.start(t);
    osc.stop(t + 5.1);
  });
}

// ─── Internals ──────────────────────────────────────────────────────────────

function context() {
  if (!ctx) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    ctx = new AudioCtx();
    master = ctx.createGain();
    master.gain.value = volume;
    master.connect(ctx.destination);
    // iOS reports 'interrupted' after a call or Siri; Chrome reports 'suspended'. Re-arm either way.
    ctx.onstatechange = () => {
      if (ctx.state !== 'running' && ctx.state !== 'closed' && voices.size) ctx.resume?.().catch(() => {});
    };
  }
  // 'suspended' (autoplay policy) or 'interrupted' (iOS): resume. Called from taps, so it is allowed.
  if (ctx.state !== 'running' && ctx.state !== 'closed') ctx.resume?.().catch(() => {});
  return ctx;
}

function setAudioSession(type) {
  try {
    if (navigator.audioSession && navigator.audioSession.type !== type) navigator.audioSession.type = type;
  } catch {
    // Not supported: the ring/silent switch rules apply (see the FAQ).
  }
}

function rampTo(param, value, timeConstant) {
  const t = ctx.currentTime;
  if (param.cancelAndHoldAtTime) param.cancelAndHoldAtTime(t);
  else {
    param.cancelScheduledValues(t);
    param.setValueAtTime(param.value, t);
  }
  param.setTargetAtTime(value, t, timeConstant);
}

function buildBrown(ac, out) {
  const bed = loop(ac, noise(ac, 'brown'));
  chain(bed, filter(ac, 'lowpass', 900), gain(ac, 0.55), out);
  return [bed];
}

function buildRain(ac, out) {
  const bed = loop(ac, noise(ac, 'pink'));
  const bedGain = gain(ac, 0.3);
  chain(bed, filter(ac, 'highpass', 450), filter(ac, 'lowpass', 6500), bedGain, out);
  const swell = lfo(ac, 0.07, 0.08, bedGain.gain);

  const drops = loop(ac, noise(ac, 'drops'));
  chain(drops, filter(ac, 'highpass', 1200), gain(ac, 0.35), out);
  return [bed, swell, drops];
}

function buildCabin(ac, out) {
  const hearth = loop(ac, noise(ac, 'brown'));
  const hearthGain = gain(ac, 0.5);
  chain(hearth, filter(ac, 'lowpass', 220), hearthGain, out);
  const breathe = lfo(ac, 0.2, 0.12, hearthGain.gain);

  const crackle = loop(ac, noise(ac, 'crackle'));
  chain(crackle, filter(ac, 'highpass', 700), gain(ac, 0.45), out);

  const wind = loop(ac, noise(ac, 'pink'));
  const windBand = filter(ac, 'bandpass', 380, 0.8);
  const windGain = gain(ac, 0.14);
  chain(wind, windBand, windGain, out);
  const gust = lfo(ac, 0.05, 0.09, windGain.gain);
  const sway = lfo(ac, 0.03, 160, windBand.frequency);

  return [hearth, breathe, crackle, wind, gust, sway];
}

// Node helpers

function loop(ac, buffer) {
  const src = ac.createBufferSource();
  src.buffer = buffer;
  src.loop = true;
  // Random offset so layers sharing a buffer never line up.
  src.start(ac.currentTime, Math.random() * buffer.duration);
  return src;
}

function filter(ac, type, frequency, Q = 0.707) {
  const node = ac.createBiquadFilter();
  node.type = type;
  node.frequency.value = frequency;
  node.Q.value = Q;
  return node;
}

function gain(ac, value) {
  const node = ac.createGain();
  node.gain.value = value;
  return node;
}

function lfo(ac, rate, depth, param) {
  const osc = ac.createOscillator();
  osc.frequency.value = rate;
  osc.connect(gain(ac, depth)).connect(param);
  osc.start();
  return osc;
}

const chain = (...nodes) => nodes.reduce((from, to) => from.connect(to));

// Buffer generation (stereo, generated once per session)

const GENERATORS = {
  brown: [8, fillBrown],
  pink: [8, fillPink],
  drops: [6, fillDrops],
  crackle: [12, fillCrackle],
};

function noise(ac, kind) {
  if (!buffers[kind]) {
    const [seconds, fill] = GENERATORS[kind];
    const length = Math.floor(seconds * ac.sampleRate);
    const buffer = ac.createBuffer(2, length, ac.sampleRate);
    for (let ch = 0; ch < 2; ch++) fill(buffer.getChannelData(ch), ac.sampleRate);
    buffers[kind] = buffer;
  }
  return buffers[kind];
}

const white = () => Math.random() * 2 - 1;

/** Removes the DC step between the last and first sample so the loop point is silent. */
function seamless(data) {
  const step = (data[data.length - 1] - data[0]) / (data.length - 1);
  for (let i = 0; i < data.length; i++) data[i] -= step * i;
}

function fillBrown(data) {
  let last = 0;
  for (let i = 0; i < data.length; i++) {
    last = (last + 0.02 * white()) / 1.02;
    data[i] = last * 3.5;
  }
  seamless(data);
}

// Paul Kellet's economy pink-noise filter.
function fillPink(data) {
  let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
  for (let i = 0; i < data.length; i++) {
    const w = white();
    b0 = 0.99886 * b0 + w * 0.0555179;
    b1 = 0.99332 * b1 + w * 0.0750759;
    b2 = 0.969 * b2 + w * 0.153852;
    b3 = 0.8665 * b3 + w * 0.3104856;
    b4 = 0.55 * b4 + w * 0.5329522;
    b5 = -0.7616 * b5 - w * 0.016898;
    data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
    b6 = w * 0.115926;
  }
  seamless(data);
}

/** Hundreds of tiny decaying "plinks" per second read as rain patter. */
function fillDrops(data, sampleRate) {
  const count = (data.length / sampleRate) * 220;
  for (let k = 0; k < count; k++) {
    const tau = (0.002 + Math.random() * 0.004) * sampleRate;
    const span = Math.floor(tau * 6);
    const start = Math.floor(Math.random() * (data.length - span));
    const omega = (2 * Math.PI * (1800 + Math.random() * 4200)) / sampleRate;
    const amp = Math.random() ** 3 * 0.5;
    for (let j = 0; j < span; j++) data[start + j] += amp * Math.exp(-j / tau) * Math.sin(omega * j);
  }
}

/** Clusters of sharp noise clicks, occasionally a louder pop, read as a wood fire. */
function fillCrackle(data, sampleRate) {
  const clusters = (data.length / sampleRate) * 4;
  for (let c = 0; c < clusters; c++) {
    const at = Math.floor(Math.random() * (data.length - sampleRate * 0.2));
    const clicks = 1 + Math.floor(Math.random() * 6);
    for (let k = 0; k < clicks; k++) {
      const tau = (0.0005 + Math.random() * 0.002) * sampleRate;
      const start = at + Math.floor(Math.random() * 0.08 * sampleRate);
      const amp = (0.2 + Math.random() * 0.8) * (Math.random() < 0.15 ? 1 : 0.4);
      for (let j = 0; j < tau * 8; j++) data[start + j] += amp * Math.exp(-j / tau) * white();
    }
  }
}
