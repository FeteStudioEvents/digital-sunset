import { clock, dayKey } from '../core/clock.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { getRitual } from './ritual-timer.js';
import { promptById } from './prompts.js';

export const ARCHIVE_NIGHTS = 14;

/**
 * Clears the mind-dump journal at local midnight so every morning starts with a blank page.
 *
 * - App open at midnight: the clock's day-change event clears it on the spot.
 * - App closed at midnight: on next launch, a journal dated before today is cleared.
 * - Ritual running across midnight (a late sunset): the clear waits until the ritual
 *   ends, so text never vanishes while someone is mid-thought.
 * - "Keep my notes" on (Settings): the page is still cleared, but its text is first
 *   filed in a local archive of the last 14 nights. Off (the default): it is simply gone.
 *
 * Views watch `journal.resetAt` to drop any unsaved draft they are holding.
 */
export const journalDay = ({ day, updatedAt }) => day ?? (updatedAt ? dayKey(new Date(updatedAt)) : null);

/** Files a page in the archive under the day it was written. Same-day pages are joined. */
export function archivePage(journal, archive = store.get().archive) {
  const text = journal.text.trim();
  if (!text) return archive;
  const day = journalDay(journal) ?? dayKey();
  const prompt = promptById(journal.promptId)?.text ?? null;
  const existing = archive.find((n) => n.day === day);
  const entry = existing
    ? { ...existing, text: `${existing.text}\n\n${text}`, savedAt: Date.now() }
    : { day, text, prompt, savedAt: Date.now() };
  return [entry, ...archive.filter((n) => n.day !== day)]
    .sort((a, b) => (a.day < b.day ? 1 : -1))
    .slice(0, ARCHIVE_NIGHTS);
}

export function startJournalReset() {
  let pending = false;

  function clearNow() {
    pending = false;
    const { journal, settings, archive } = store.get();
    const hadText = Boolean(journal.text.trim());
    const keep = settings.keepNotes && hadText;
    store.set({
      ...(keep ? { archive: archivePage(journal, archive) } : {}),
      journal: { text: '', updatedAt: null, day: dayKey(), resetAt: Date.now(), promptId: null },
    });
    if (keep) toast('A new day. Last night’s notes are in Saved nights, and the page is fresh.', { duration: 6000 });
    else if (hadText) toast('A new day. Your mind dump has been cleared for a fresh start.', { duration: 6000 });
  }

  function requestClear() {
    if (getRitual().status === 'active') pending = true;
    else clearNow();
  }

  function isStale() {
    const { journal } = store.get();
    const day = journalDay(journal);
    return Boolean(journal.text) && day !== null && day !== dayKey();
  }

  if (isStale()) requestClear();

  const offDay = clock.onDayChange(() => {
    if (isStale()) requestClear();
  });
  const offStore = store.subscribe(({ ritual }) => {
    if (pending && ritual.status !== 'active') clearNow();
  });

  return () => {
    offDay();
    offStore();
  };
}
