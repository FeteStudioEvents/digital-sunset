/**
 * Install hints for the first-run welcome.
 *
 * - Already running from the home screen (any app display mode, or iOS's
 *   navigator.standalone): no hint at all.
 * - Android/desktop Chrome: the browser's own install prompt is captured and offered
 *   as an "Install" button; until it arrives, the menu route is described.
 * - iPhone/iPad: Share → Add to Home Screen (iOS has no install prompt).
 */
let deferred = null;
const listeners = new Set();

export function captureInstallPrompt() {
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault(); // show our own quiet button instead of the browser's mini-infobar
    deferred = event;
    listeners.forEach((fn) => fn(true));
  });
  window.addEventListener('appinstalled', () => {
    deferred = null;
    listeners.forEach((fn) => fn(false));
  });
}

export function onInstallAvailability(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export const canPromptInstall = () => Boolean(deferred);

export async function promptInstall() {
  if (!deferred) return 'unavailable';
  const event = deferred;
  deferred = null;
  listeners.forEach((fn) => fn(false));
  event.prompt();
  const { outcome } = await event.userChoice;
  return outcome; // 'accepted' | 'dismissed'
}

export function isStandalone() {
  const modes = ['standalone', 'fullscreen', 'minimal-ui', 'window-controls-overlay'];
  // A browser tab in element fullscreen (the ritual's focus lock) is not "installed".
  const inElementFullscreen = Boolean(document.fullscreenElement);
  return navigator.standalone === true
    || (!inElementFullscreen && modes.some((m) => window.matchMedia?.(`(display-mode: ${m})`).matches));
}

export function platform() {
  const ua = navigator.userAgent;
  if (/iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) return 'ios';
  if (/Android/.test(ua)) return 'android';
  return 'desktop';
}
