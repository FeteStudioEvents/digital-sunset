import { dayKey } from '../core/clock.js';
import { store } from '../core/store.js';
import { PROMPTS, PROMPTS_BY_ID } from '../data/prompts.js';

/**
 * Nightly prompt rotation.
 *
 * Prompts are dealt from a shuffled cycle saved on the device: every prompt appears
 * once before any repeats, then a fresh shuffle starts (never opening with the prompt
 * just shown). Swaps are dealt from the same cycle, so they count as seen.
 *
 * A "night" runs from 4 am to 4 am, so a sunset begun at 11:30 pm keeps its prompt
 * past midnight. Each night gets one prompt and up to MAX_SWAPS replacements.
 */
export const MAX_SWAPS = 2;
const NIGHT_ROLLOVER_HOURS = 4;

export function nightKey(now = new Date()) {
  return dayKey(new Date(now.getTime() - NIGHT_ROLLOVER_HOURS * 3600_000));
}

function shuffle(ids) {
  const a = [...ids];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Repairs a saved cycle against the current prompt list (prompts added or removed in an update). */
function normalise({ order, pos }) {
  const valid = new Set(PROMPTS_BY_ID.keys());
  const seen = order.slice(0, pos).filter((id) => valid.has(id));
  const rest = order.slice(pos).filter((id) => valid.has(id));
  const known = new Set([...seen, ...rest]);
  const added = PROMPTS.map((p) => p.id).filter((id) => !known.has(id));
  return { order: [...seen, ...shuffle([...rest, ...added])], pos: seen.length };
}

function deal(state) {
  let { order, pos } = normalise(state);
  if (pos >= order.length) {
    order = shuffle(PROMPTS.map((p) => p.id));
    // Don't open a new cycle with the prompt that closed the last one.
    if (order.length > 1 && order[0] === state.current) [order[0], order[1]] = [order[1], order[0]];
    pos = 0;
  }
  return { order, pos: pos + 1, current: order[pos] };
}

/** Tonight's prompt, dealing a new one the first time it is asked for on a new night. */
export function promptForTonight(now = new Date()) {
  const night = nightKey(now);
  let state = store.get().prompts;
  if (state.night !== night || !PROMPTS_BY_ID.has(state.current)) {
    state = { ...state, ...deal(state), night, swaps: 0 };
    store.set({ prompts: state });
  }
  return PROMPTS_BY_ID.get(state.current);
}

export function swapsLeft(now = new Date()) {
  const state = store.get().prompts;
  if (state.night !== nightKey(now)) return MAX_SWAPS;
  return Math.max(0, MAX_SWAPS - state.swaps);
}

/** Replaces tonight's prompt with the next one in the cycle. Returns null once the swaps are used up. */
export function swapPrompt(now = new Date()) {
  promptForTonight(now);
  const state = store.get().prompts;
  if (state.swaps >= MAX_SWAPS) return null;
  const next = { ...state, ...deal(state), swaps: state.swaps + 1 };
  store.set({ prompts: next });
  return PROMPTS_BY_ID.get(next.current);
}

export const promptById = (id) => PROMPTS_BY_ID.get(id) ?? null;
