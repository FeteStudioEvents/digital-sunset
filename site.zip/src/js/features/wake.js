/**
 * Keeps the screen on while a ritual runs, so the sunset can be watched to the end.
 *
 * 1. Screen Wake Lock API (Chrome/Android, Safari 16.4+). The browser drops the lock
 *    whenever the app is hidden, so it is re-requested each time the app is visible again.
 * 2. Fallback: a tiny muted, looping inline video. Playing video keeps the screen awake on
 *    browsers without the API, and on iOS versions where the lock was unreliable inside
 *    home-screen apps (before iOS 18.4). Start it from a tap so iOS allows playback.
 *
 * The active method is mirrored to <html data-wake="lock|video|none"> for diagnostics.
 */
let wanted = false;
let sentinel = null;
let video = null;

const root = () => document.documentElement;
const setMode = (mode) => { root().dataset.wake = mode; };

function needsVideoToo() {
  const ua = navigator.userAgent;
  const iOS = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  if (!iOS) return false;
  const m = ua.match(/OS (\d+)[._](\d+)/);
  if (!m) return true;
  const [major, minor] = [Number(m[1]), Number(m[2])];
  return major < 18 || (major === 18 && minor < 4);
}

async function requestLock() {
  if (!('wakeLock' in navigator) || document.visibilityState !== 'visible') return false;
  try {
    sentinel = await navigator.wakeLock.request('screen');
    sentinel.addEventListener('release', () => { sentinel = null; });
    if (!wanted) { // ritual ended while the request was in flight
      sentinel.release().catch(() => {});
      return false;
    }
    return true;
  } catch {
    sentinel = null; // NotAllowedError (battery saver, permissions policy) → fallback
    return false;
  }
}

function startVideo() {
  if (!video) {
    video = document.createElement('video');
    video.className = 'keep-awake';
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    video.setAttribute('aria-hidden', 'true');
    video.setAttribute('tabindex', '-1');
    for (const [src, type] of [['assets/media/keep-awake.webm', 'video/webm'], ['assets/media/keep-awake.mp4', 'video/mp4']]) {
      const source = document.createElement('source');
      source.src = src;
      source.type = type;
      video.append(source);
    }
    document.body.append(video);
  }
  const playing = video.play();
  return playing?.then ? playing.then(() => true, () => false) : Promise.resolve(true);
}

async function acquire() {
  if (!wanted) return;
  const locked = await requestLock();
  let videoOn = false;
  if (!locked || needsVideoToo()) videoOn = await startVideo();
  if (!wanted) return;
  setMode(locked ? 'lock' : videoOn ? 'video' : 'none');
}

function onVisibility() {
  if (document.visibilityState === 'visible' && wanted && !sentinel) acquire();
}

/** Call from the tap that starts (or resumes) a ritual. Returns a release function. */
export function keepAwake() {
  if (!wanted) {
    wanted = true;
    document.addEventListener('visibilitychange', onVisibility);
  }
  acquire();
  return releaseAwake;
}

export function releaseAwake() {
  wanted = false;
  document.removeEventListener('visibilitychange', onVisibility);
  sentinel?.release().catch(() => {});
  sentinel = null;
  if (video) {
    video.pause();
    video.remove();
    video = null;
  }
  delete root().dataset.wake;
}
