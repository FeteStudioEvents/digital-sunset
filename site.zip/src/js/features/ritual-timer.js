import { LENGTHS, store } from '../core/store.js';

const MINUTE = 60 * 1000;
export const DEFAULT_MS = 60 * MINUTE;

/**
 * Ritual state lives in the store as an absolute end time rather than a
 * running counter, so it stays accurate across reloads, sleep, and app switches.
 * Each ritual records its own length, so changing the setting never alters one
 * that is already running.
 *
 * status: 'idle' → 'active' → 'complete' → 'idle'
 *                     └─ ended early ──────→ 'idle'
 */
export const getRitual = () => store.get().ritual;

/** The length the next ritual will use, from Settings (30, 45 or 60 minutes). */
export function chosenMs() {
  const min = Number(store.get().settings.lengthMin);
  return (LENGTHS.includes(min) ? min : 60) * MINUTE;
}

/** Length of the ritual in progress, or of the next one when idle. */
export function durationMs(ritual = getRitual()) {
  if (ritual.status === 'idle') return chosenMs();
  return ritual.durationMs || DEFAULT_MS;
}

export function remainingMs(ritual = getRitual(), now = Date.now()) {
  if (ritual.status === 'active') return Math.max(0, ritual.endsAt - now);
  if (ritual.status === 'complete') return 0;
  return chosenMs();
}

/** 0 at the start of a ritual → 1 when the sun has set. */
export function progress(ritual = getRitual(), now = Date.now()) {
  const total = durationMs(ritual);
  return Math.min(1, Math.max(0, 1 - remainingMs(ritual, now) / total));
}

export function startRitual(now = Date.now()) {
  const ms = chosenMs();
  store.set({ ritual: { status: 'active', startedAt: now, endsAt: now + ms, durationMs: ms, returns: 0 } });
}

export function completeRitual() {
  store.set(({ ritual }) => ({ ritual: { ...ritual, status: 'complete' } }));
}

export function resetRitual() {
  store.set({ ritual: { status: 'idle', startedAt: null, endsAt: null, durationMs: chosenMs(), returns: 0 } });
}

/** Counts each time the user left the app mid-ritual and came back. */
export function noteReturn() {
  store.set(({ ritual }) => ({ ritual: { ...ritual, returns: ritual.returns + 1 } }));
}

/** Calls onTick once per displayed second and onComplete once when time runs out. */
export function watchRitual({ onTick, onComplete }) {
  let lastSecond = null;
  let done = false;

  const tick = () => {
    const ms = remainingMs();
    const second = Math.ceil(ms / 1000);
    if (second !== lastSecond) {
      lastSecond = second;
      onTick(ms);
    }
    if (ms <= 0 && !done) {
      done = true;
      clearInterval(id);
      onComplete();
    }
  };

  const id = setInterval(tick, 250);
  tick();
  return () => clearInterval(id);
}

export function formatClock(ms) {
  const total = Math.ceil(ms / 1000);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(Math.floor(total / 60))}:${pad(total % 60)}`;
}
