import { store } from '../core/store.js';

/** True when this device can vibrate at all (Android browsers; not iPhone Safari). */
export const hapticsSupported = () => typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';

/** A short, gentle buzz, if the device supports it and Settings → Haptics is on. */
export function haptic(pattern = 12) {
  if (!store.get().settings.haptics || !hapticsSupported()) return;
  // Chrome blocks (and logs) vibration before the first tap on the page.
  if (navigator.userActivation && !navigator.userActivation.hasBeenActive) return;
  try {
    navigator.vibrate(pattern);
  } catch {
    // Some browsers throw outside a user gesture; haptics are decoration only.
  }
}
