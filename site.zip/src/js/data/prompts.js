/**
 * Evening mindfulness prompts, written for Digital Sunset.
 *
 * Gentle reflection only: no advice, diagnosis or promises of outcome.
 * Ids are stable ("release-01"…). The rotation stores ids, so you can add prompts
 * at any time; new ones join the unseen part of the current cycle.
 * Do not reuse or renumber an id for different text.
 */

export const CATEGORIES = {
  release: 'Release',
  gratitude: 'Gratitude',
  body: 'Body',
  tomorrow: 'Tomorrow',
  wonder: 'Wonder',
};

const TEXT = {
  release: [
    'What is one thing from today you can set down now, even if you pick it back up tomorrow?',
    'Name a worry that doesn’t need an answer tonight.',
    'If today had a closing sentence, what would it say?',
    'What did you carry around today that wasn’t yours to carry?',
    'Write down the one task still circling your head, then tell it: “Tomorrow.”',
    'Which conversation from today can you stop replaying?',
    'What’s one expectation of yourself you can loosen for tonight?',
    'Describe today’s hardest moment in three words, then close the door on it.',
    'What can be good enough, just as it is?',
    'What are you still holding your breath about? Let it out on the page.',
    'Is there something you said yes to that you’d like to gently undo?',
    'What would it feel like to be finished for the day?',
    'List anything unfinished. Unfinished is allowed.',
    'What did today ask of you? Thank it, and let it go.',
    'What would you let go of tonight if no one else would ever know?',
  ],
  gratitude: [
    'What small thing went right today?',
    'Who made your day a little easier, even without knowing it?',
    'Name a sound, a taste and a texture you liked today.',
    'What’s something you own that quietly makes life better?',
    'Which moment from today would you happily live again?',
    'What’s one kind thing you did today, however small?',
    'What comfort do you have tonight that you sometimes forget?',
    'Who would you thank, if you could send one note tonight?',
    'What made you smile today, even for a second?',
    'What’s a place you’re glad exists?',
    'Think of a meal you enjoyed recently. What made it good?',
    'What did your past self do that helped you today?',
    'What did you learn today, even something tiny?',
    'Which part of this evening are you enjoying most?',
    'Name three ordinary things that were quietly wonderful today.',
  ],
  body: [
    'Where in your body are you holding the day? Let that spot soften.',
    'Unclench your jaw and drop your shoulders. What changed?',
    'How do your feet feel right now? Describe them without judging.',
    'Take three slow breaths. What did you notice on the third one?',
    'What does your body want more of tonight: warmth, stillness, a stretch or rest?',
    'Notice the weight of your hands. Let them be heavy.',
    'What’s the most comfortable position you could be in right now?',
    'Which part of you worked hardest today? Thank it.',
    'Is there a small stretch your body is asking for?',
    'How does the air around you feel on your skin?',
    'Breathe out a little longer than you breathe in, five times. What do you notice?',
    'Scan from your forehead down to your toes. Where are you already calm?',
    'What did you give your body today that it liked?',
    'Notice your breath without changing it. Just watch it for a minute.',
    'If your energy had a colour right now, what would it be?',
  ],
  tomorrow: [
    'What’s one thing you’d love tomorrow to include?',
    'What’s the first kind thing you’ll do for yourself tomorrow?',
    'Write the three things that matter tomorrow. Everything else can wait.',
    'What could you set out tonight so tomorrow morning feels easier?',
    'Which task feels big? What’s its smallest first step?',
    'What would make tomorrow a good day, even if nothing else goes to plan?',
    'Who might you reach out to tomorrow?',
    'What’s something tomorrow doesn’t need from you?',
    'Picture tomorrow evening. What would you like to be glad about?',
    'What can you say no to tomorrow?',
    'Choose one word to carry into tomorrow.',
    'What small pleasure can you plan for tomorrow?',
    'What would you tell a friend who had your tomorrow ahead of them?',
    'What have you been putting off that would feel lighter once started?',
    'What’s the first thing you’d like to see when you wake up?',
  ],
  wonder: [
    'What did you notice today that you usually miss?',
    'If you could spend tonight anywhere in the world, where would it be?',
    'What’s a question you’d love to know the answer to?',
    'Describe the sky the last time you looked up.',
    'What’s a memory that still feels warm when you think of it?',
    'What did you love doing when you were eight?',
    'If tonight were a colour, which one would it be, and why?',
    'What’s a small mystery in your life you’re happy not to solve?',
    'Somewhere, someone is looking at the same moon. What would you say to them?',
    'What’s something beautiful you’ve seen this week?',
    'What would you like to get better at, just for the joy of it?',
    'Which smell takes you straight back to a happy place?',
    'If today were a chapter in a book, what would its title be?',
    'What would your ideal slow Sunday look like?',
    'What’s a sound you love falling asleep to?',
  ],
};

export const PROMPTS = Object.entries(TEXT).flatMap(([category, list]) =>
  list.map((text, i) => ({ id: `${category}-${String(i + 1).padStart(2, '0')}`, category, text })),
);

export const PROMPTS_BY_ID = new Map(PROMPTS.map((p) => [p.id, p]));
