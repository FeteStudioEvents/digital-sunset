import { html, render, qs, qsa, on } from '../core/dom.js';
import { LENGTHS, store, updateSettings } from '../core/store.js';
import { APP_VERSION } from '../core/version.js';
import * as ambient from '../features/ambient.js';
import { hapticsSupported } from '../features/haptics.js';

/**
 * Settings, as a bottom sheet built on <dialog>: the browser supplies the focus trap,
 * Escape to close, and an inert page behind it.
 */
let dialog = null;
let opener = null;

const pct = (v) => `${Math.round(Number(v) * 100)}%`;

function template({ settings, archive }) {
  return html`
    <div class="sheet__inner">
      <header class="sheet__head">
        <h2 id="settings-title">Settings</h2>
        <button class="icon-btn" type="button" data-action="close" aria-label="Close settings">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
        </button>
      </header>

      <fieldset class="sheet__group">
        <legend class="eyebrow eyebrow--muted">Ritual length</legend>
        <div class="segmented segmented--wide">
          ${LENGTHS.map((min) => html`
            <label class="segmented__opt">
              <input type="radio" name="sheet-length" value="${min}" ${Number(settings.lengthMin) === min ? 'checked' : ''}>
              <span>${min} min</span>
            </label>`)}
        </div>
        <p class="hint">The sun and the countdown stretch to fit. Applies to your next sunset.</p>
      </fieldset>

      <fieldset class="sheet__group">
        <legend class="eyebrow eyebrow--muted">Sound levels</legend>
        ${ambient.SOUND_LIST.map(({ id, label }) => html`
          <div class="slider-row">
            <label for="level-${id}">${label}</label>
            <input type="range" id="level-${id}" min="0" max="1" step="0.05" value="${settings.volumes[id] ?? 0.7}"
                   data-layer="${id}" aria-describedby="level-${id}-out">
            <output id="level-${id}-out" for="level-${id}" data-out="${id}">${pct(settings.volumes[id] ?? 0.7)}</output>
          </div>`)}
        <p class="hint">Each layer remembers its level. The slider beside Ambience sets the overall volume.</p>
      </fieldset>

      <div class="sheet__group">
        <label class="switch-row">
          <span class="switch-row__text">
            <span class="switch-row__title">Haptics</span>
            <span class="hint" id="haptics-hint">${hapticsSupported()
              ? 'A gentle buzz when a sunset starts, ends, or is held to finish.'
              : 'A gentle buzz on start and finish. This browser doesn’t support vibration (iPhone doesn’t allow it for web apps).'}</span>
          </span>
          <input type="checkbox" role="switch" class="switch" data-setting="haptics" aria-describedby="haptics-hint" ${settings.haptics ? 'checked' : ''}>
        </label>

        <label class="switch-row">
          <span class="switch-row__text">
            <span class="switch-row__title">Keep my notes</span>
            <span class="hint" id="keep-hint">Off: the mind dump clears at midnight and is gone, a true fresh start. On: the page still clears, but the last 14 nights are kept on this device.</span>
          </span>
          <input type="checkbox" role="switch" class="switch" data-setting="keepNotes" aria-describedby="keep-hint" ${settings.keepNotes ? 'checked' : ''}>
        </label>
        <a class="btn btn--ghost sheet__archive" href="#/archive" data-action="archive" data-el="archive-link"
           ${settings.keepNotes || archive.length ? '' : 'hidden'}>View saved nights (${archive.length})</a>
      </div>

      <div class="sheet__group">
        <h3 class="eyebrow eyebrow--muted">Your data</h3>
        <button class="btn btn--ghost btn--danger-ghost" type="button" data-action="reset-ask" data-el="reset-ask">Reset app data</button>
        <div class="confirm" data-el="reset-confirm" role="group" aria-labelledby="reset-q" hidden>
          <p id="reset-q">Erase your mind dump, saved nights, settings and prompt history from this device? This can’t be undone.</p>
          <div class="row">
            <button class="btn btn--ghost" type="button" data-action="reset-cancel">Cancel</button>
            <button class="btn btn--danger" type="button" data-action="reset-confirm">Erase everything</button>
          </div>
        </div>
      </div>

      <div class="sheet__group about">
        <h3 class="eyebrow eyebrow--muted">About</h3>
        <p>Everything stays on your device. No accounts, no tracking.</p>
        <p>A wind-down ritual, not therapy.</p>
        <p class="text-muted text-sm">Digital Sunset ${APP_VERSION} · © 2026 Fête Studio Events · <a class="legal-link" href="LICENSE.txt" target="_blank" rel="noopener">Personal-use license</a></p>
      </div>
    </div>
  `;
}

function build() {
  dialog = document.createElement('dialog');
  dialog.className = 'sheet';
  dialog.setAttribute('aria-labelledby', 'settings-title');
  document.body.append(dialog);

  const el = (name) => qs(`[data-el="${name}"]`, dialog);

  const actions = {
    close: () => dialog.close(),
    archive: (_, e) => {
      e.preventDefault();
      dialog.close();
      location.hash = '/archive';
    },
    'reset-ask': () => {
      el('reset-ask').hidden = true;
      el('reset-confirm').hidden = false;
      qs('[data-action="reset-cancel"]', dialog).focus();
    },
    'reset-cancel': () => {
      el('reset-confirm').hidden = true;
      el('reset-ask').hidden = false;
      el('reset-ask').focus();
    },
    'reset-confirm': () => {
      ambient.stopAll();
      store.wipe();
      history.replaceState(null, '', location.pathname + location.search);
      location.reload();
    },
  };
  on(dialog, 'click', '[data-action]', (e, btn) => actions[btn.dataset.action]?.(btn, e));

  // Tap on the dimmed backdrop closes the sheet.
  dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });

  on(dialog, 'change', 'input[name="sheet-length"]', (_, input) => updateSettings({ lengthMin: Number(input.value) }));
  on(dialog, 'input', 'input[data-layer]', (_, input) => {
    ambient.setLayerVolume(input.dataset.layer, Number(input.value));
    qs(`[data-out="${input.dataset.layer}"]`, dialog).textContent = pct(input.value);
  });
  on(dialog, 'change', 'input[data-layer]', (_, input) => {
    const { volumes } = store.get().settings;
    updateSettings({ volumes: { ...volumes, [input.dataset.layer]: Number(input.value) } });
  });
  on(dialog, 'change', 'input[data-setting]', (_, input) => {
    updateSettings({ [input.dataset.setting]: input.checked });
    const { settings, archive } = store.get();
    el('archive-link').hidden = !(settings.keepNotes || archive.length);
  });

  dialog.addEventListener('close', () => {
    document.documentElement.removeAttribute('data-sheet');
    // Browsers restore focus on close; only step in if focus was lost (never steal it back).
    const lost = !document.activeElement || document.activeElement === document.body;
    if (lost && opener?.isConnected) opener.focus();
    opener = null;
  });
}

export function openSettings(from = document.activeElement) {
  if (!dialog) build();
  if (dialog.open) return;
  opener = from;
  render(dialog, template(store.get()));
  document.documentElement.dataset.sheet = 'open';
  dialog.showModal();
  qs('[data-action="close"]', dialog).focus();
}

export const settingsOpen = () => Boolean(dialog?.open);

// Keep values in step if the home-screen length picker changes while the sheet is open.
store.subscribe(({ settings }) => {
  if (!dialog?.open) return;
  qsa('input[name="sheet-length"]', dialog).forEach((r) => { r.checked = Number(r.value) === Number(settings.lengthMin); });
});
