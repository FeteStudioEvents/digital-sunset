import { clock, dayKey } from '../core/clock.js';
import { html, raw, render, qs, qsa, on } from '../core/dom.js';
import { onSuspend } from '../core/session.js';
import { LENGTHS, store, updateSettings } from '../core/store.js';
import { toast } from '../core/toast.js';
import * as ambient from '../features/ambient.js';
import { haptic } from '../features/haptics.js';
import {
  canPromptInstall, isStandalone, onInstallAvailability, platform, promptInstall,
} from '../features/install.js';
import { copyText, fileName, formatPage, pageFromJournal, saveTextFile } from '../features/journal-export.js';
import { engageLockdown, setRitualMode } from '../features/lockdown.js';
import { CATEGORIES } from '../data/prompts.js';
import { promptForTonight, swapPrompt, swapsLeft } from '../features/prompts.js';
import {
  completeRitual, durationMs, formatClock, getRitual, noteReturn,
  progress, remainingMs, resetRitual, startRitual, watchRitual,
} from '../features/ritual-timer.js';
import { keepAwake, releaseAwake } from '../features/wake.js';

export const title = 'Digital Sunset';

const HOLD_MS = 1500;
const MINUTE = 60 * 1000;
const LENGTH_WORDS = { 30: 'Thirty', 45: 'Forty-five', 60: 'Sixty' };
const LENGTH_PHRASE = { 30: 'Half an hour', 45: 'Forty-five minutes', 60: 'One hour' };

const ICONS = {
  brown: html`<svg viewBox="0 0 24 24" class="sound__icon" aria-hidden="true"><path d="M3 9c3-3 6 3 9 0s6-3 9 0M3 15c3-3 6 3 9 0s6-3 9 0"/></svg>`,
  rain: html`<svg viewBox="0 0 24 24" class="sound__icon" aria-hidden="true"><path d="M7 4.5 5.5 9M12.5 3 11 7.5M18 4.5 16.5 9M9.5 12 8 16.5M15 12l-1.5 4.5M12 18.5 11 21"/></svg>`,
  cabin: html`<svg viewBox="0 0 24 24" class="sound__icon" aria-hidden="true"><path d="M3 11 11 4l8 7M5 9.5V20h12V9.5M9.5 20v-5h3v5M19.5 20 21 17l-1.5-4L18 17z"/></svg>`,
};
const SHARE_ICON = raw('<svg class="inline-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12M8 7l4-4 4 4M6 11H5v10h14V11h-1"/></svg>');

function caption(status, ms, total) {
  if (status === 'idle') {
    const min = Math.round(total / MINUTE);
    return `${LENGTH_PHRASE[min] ?? `${min} minutes`} to let the day go. Screens dim, sound softens, thoughts land on paper.`;
  }
  if (status === 'complete') return 'The sun has set. Rest well.';
  if (ms > (total * 5) / 6) return 'Dim the lights. Let the day settle.';
  if (ms > total / 6) return 'The sun is going down. Nothing needs you now.';
  return 'Almost dark. Breathe a little slower.';
}

const swapsLabel = (n) => (n === 0 ? 'No more swaps tonight' : `${n} ${n === 1 ? 'swap' : 'swaps'} left tonight`);

function installHint() {
  if (isStandalone()) return '';
  const os = platform();
  if (os === 'ios') {
    return html`<p class="install-hint__text"><strong>Add it to your Home Screen:</strong> in Safari, tap Share ${SHARE_ICON}, then <em>Add to Home Screen</em>.</p>`;
  }
  const button = html`<button class="btn" type="button" data-action="install" data-el="install-btn" ${canPromptInstall() ? '' : 'hidden'}>Install app</button>`;
  if (os === 'android') {
    return html`<p class="install-hint__text"><strong>Add it to your home screen:</strong> tap <em>Install</em>, or in Chrome open the ⋮ menu and choose <em>Install app</em>.</p>${button}`;
  }
  return html`<p class="install-hint__text"><strong>Best on your phone:</strong> open this page there and add it to your home screen, or install it here from your browser’s menu.</p>${button}`;
}

function welcomeCard() {
  return html`
    <section class="welcome" data-el="welcome" data-show="idle" aria-labelledby="welcome-title">
      <h2 class="welcome__title" id="welcome-title">Welcome to your Digital Sunset</h2>
      <ol class="welcome__lines">
        <li>Choose 30, 45 or 60 minutes and tap <em>Begin sunset</em>.</li>
        <li>Layer a soft sound, answer tonight’s prompt, empty your head onto the page.</li>
        <li>The screen dims with the light, and at midnight the page clears for a fresh start.</li>
      </ol>
      <div class="install-hint" data-el="install-hint">${installHint()}</div>
      <button class="btn btn--ghost welcome__ok" type="button" data-action="welcome-ok">Got it</button>
    </section>
  `;
}

function lengthPicker(selected) {
  return html`
    <fieldset class="segmented" data-show="idle" data-el="length">
      <legend class="sr-only">Ritual length</legend>
      ${LENGTHS.map((min) => html`
        <label class="segmented__opt">
          <input type="radio" name="home-length" value="${min}" ${min === selected ? 'checked' : ''}>
          <span>${min} min</span>
        </label>`)}
    </fieldset>
  `;
}

function promptCard(prompt, left) {
  return html`
    <section class="prompt" aria-labelledby="prompt-title" data-el="prompt">
      <p class="eyebrow" id="prompt-title">Tonight’s prompt · <span data-el="prompt-cat">${CATEGORIES[prompt.category]}</span></p>
      <p class="prompt__text" data-el="prompt-text" data-prompt-id="${prompt.id}">${prompt.text}</p>
      <div class="row-between prompt__bar">
        <button class="link-btn" type="button" data-action="swap" data-el="swap" ${left ? '' : 'disabled'}
                aria-describedby="swaps-left">Different prompt</button>
        <span class="text-xs text-muted" id="swaps-left" data-el="swaps-left">${swapsLabel(left)}</span>
      </div>
    </section>
  `;
}

function template({ ritual, journal, ambient: { volume }, settings, archive, welcome }, prompt) {
  const total = durationMs(ritual);
  return html`
    <div class="ritual" data-el="ritual" data-state="${ritual.status}">
      ${welcome.dismissed ? '' : welcomeCard()}

      <div class="sky" aria-hidden="true">
        <div class="sky__layer sky__layer--dusk"></div>
        <div class="sky__layer sky__layer--night"></div>
        <div class="sky__stars"></div>
        <div class="sky__sun"></div>
        <div class="sky__ground"></div>
      </div>

      <section class="clock-block" aria-labelledby="ritual-title">
        <p class="eyebrow" id="ritual-title">
          <span class="lock-badge" data-show="active">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>
            Focus lock on
          </span>
          <span data-show="idle complete">Digital Sunset</span>
        </p>
        <div class="clock" role="timer" aria-live="off" aria-label="Time remaining" data-el="clock">${formatClock(remainingMs(ritual))}</div>
        <p class="ritual__caption" data-el="caption">${caption(ritual.status, remainingMs(ritual), total)}</p>

        ${lengthPicker(Number(settings.lengthMin))}

        <div class="swap mt-2">
          <button class="btn btn--lux" type="button" data-action="begin" data-show="idle">Begin sunset</button>
          <button class="btn btn--ghost hold" type="button" data-el="hold" data-show="active"
                  aria-label="Press and hold to end the ritual early">
            <span class="hold__fill" aria-hidden="true"></span>
            <span class="hold__label">Hold to end early</span>
          </button>
          <button class="btn btn--lux" type="button" data-action="close" data-show="complete">Close the ritual</button>
        </div>
      </section>

      ${promptCard(prompt, swapsLeft())}

      <section class="panel" aria-labelledby="ambience-title">
        <div class="row-between">
          <h2 class="eyebrow eyebrow--muted" id="ambience-title">Ambience</h2>
          <label class="volume" data-el="volume-wrap" hidden>
            <span class="sr-only">Overall volume</span>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9.5a3.5 3.5 0 0 1 0 5"/></svg>
            <input type="range" min="0" max="1" step="0.01" value="${volume}" data-el="volume">
          </label>
        </div>
        <div class="sound-grid">
          ${SOUND_TILES}
        </div>
      </section>

      <section class="panel" aria-labelledby="journal-title">
        <label class="eyebrow eyebrow--muted" id="journal-title" for="mind-dump">Mind dump</label>
        <textarea id="mind-dump" class="journal" data-el="journal" rows="6" spellcheck="true"
                  aria-describedby="journal-meta"
                  placeholder="Empty your head onto the page — to-dos, worries, half-thoughts. Nothing here leaves this device.">${journal.text}</textarea>
        <div class="journal-bar">
          <span class="text-xs text-muted" id="journal-meta" data-el="journal-meta" aria-live="polite">${journalMeta(journal.text, settings.keepNotes)}</span>
          <div class="journal-actions">
            <button class="link-btn" type="button" data-action="copy" data-needs-text ${journal.text ? '' : 'disabled'}>Copy</button>
            <button class="link-btn" type="button" data-action="save-txt" data-needs-text ${journal.text ? '' : 'disabled'}>Save .txt</button>
            <button class="link-btn" type="button" data-action="release" data-needs-text ${journal.text ? '' : 'disabled'}>Release</button>
          </div>
        </div>
        <a class="link-btn archive-link" href="#/archive" data-el="archive-link" ${settings.keepNotes || archive.length ? '' : 'hidden'}>${archiveLabel(archive.length)}</a>
      </section>

      <footer class="ritual__foot">
        <p>A wind-down ritual, not therapy.</p>
      </footer>

      <p class="sr-only" aria-live="polite" data-el="announce"></p>
    </div>
  `;
}

const archiveLabel = (n) => `Saved nights (${n})`;

const SOUND_TILES = ambient.SOUND_LIST.map(({ id, label, note }) => html`
  <button class="sound" type="button" aria-pressed="false" data-sound="${id}">
    ${ICONS[id]}
    <span class="sound__name">${label}</span>
    <span class="sound__note">${note}</span>
    <span class="sound__eq" aria-hidden="true"><i></i><i></i><i></i></span>
  </button>
`);

function journalMeta(text, keep, saving = false) {
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  if (saving) return 'Saving…';
  const fate = keep ? 'kept in Saved nights at midnight' : 'clears at midnight';
  return words
    ? `${words.toLocaleString()} ${words === 1 ? 'word' : 'words'} · on this device · ${fate}`
    : `Private · on this device · ${fate}`;
}

export function mount(root) {
  const prompt = promptForTonight();
  render(root, template(store.get(), prompt));
  const el = (name) => qs(`[data-el="${name}"]`, root);
  const ritualEl = el('ritual');
  const clockEl = el('clock');
  const captionEl = el('caption');

  let stopWatch = null;
  let releaseLock = null;
  let captionHoldUntil = 0;

  const announce = (message) => { el('announce').textContent = message; };

  function paint(ms) {
    const ritual = getRitual();
    clockEl.textContent = formatClock(ms);
    ritualEl.style.setProperty('--p', progress(ritual).toFixed(4));
    if (Date.now() > captionHoldUntil) captionEl.textContent = caption(ritual.status, ms, durationMs(ritual));
    if (ritual.status === 'active') document.title = `${formatClock(ms)} · Digital Sunset`;
  }

  function setCaption(text, holdMs) {
    captionEl.textContent = text;
    captionHoldUntil = Date.now() + holdMs;
  }

  function applyState(status, { fromGesture = false } = {}) {
    ritualEl.dataset.state = status;
    setRitualMode(status);
    releaseLock?.();
    stopWatch?.();
    releaseLock = stopWatch = null;
    captionHoldUntil = 0;

    if (status === 'active') {
      releaseLock = engageLockdown({ requestFullscreen: fromGesture, onReturn: welcomeBack });
      keepAwake();
      stopWatch = watchRitual({ onTick: paint, onComplete: finish });
    } else {
      releaseAwake();
      paint(remainingMs());
      document.title = `${title} · Fête Studio`;
    }
  }

  function welcomeBack(awayMs) {
    if (awayMs < 5000) return;
    noteReturn();
    const minutes = Math.ceil(remainingMs() / MINUTE);
    setCaption(`Welcome back. ${minutes} ${minutes === 1 ? 'minute' : 'minutes'} of sunset remain — the screen can wait.`, 8000);
  }

  function finish() {
    completeRitual();
    applyState('complete');
    ambient.fadeOutAll(45);
    ambient.chime();
    haptic([30, 80, 30]);
    announce('The sun has set. Your ritual is complete.');
  }

  // Tonight's prompt

  function showPrompt(p) {
    const textEl = el('prompt-text');
    textEl.textContent = p.text;
    textEl.dataset.promptId = p.id;
    el('prompt-cat').textContent = CATEGORIES[p.category];
    const left = swapsLeft();
    el('swaps-left').textContent = swapsLabel(left);
    el('swap').disabled = left === 0;
  }

  function swap() {
    const next = swapPrompt();
    if (!next) return;
    showPrompt(next);
    haptic(8);
    announce(`New prompt: ${next.text}`);
    if (swapsLeft() === 0) {
      // The button just disabled itself; keep keyboard focus inside the card.
      el('prompt-text').setAttribute('tabindex', '-1');
      el('prompt-text').focus({ preventScroll: true });
    }
  }

  // A new night (4 am rollover) deals a new prompt, even if the app was left open.
  const offMinute = clock.onMinute(() => {
    const current = promptForTonight();
    if (current.id !== el('prompt-text').dataset.promptId) showPrompt(current);
  });

  // Ritual controls

  const actions = {
    begin() {
      startRitual();
      haptic(15);
      applyState('active', { fromGesture: true });
      const min = Math.round(durationMs() / MINUTE);
      announce(`Ritual started. ${LENGTH_WORDS[min] ?? min} minutes.`);
    },
    close() {
      resetRitual();
      applyState('idle');
    },
    release: releaseJournal,
    copy: copyJournal,
    'save-txt': saveJournalTxt,
    swap,
    'welcome-ok': dismissWelcome,
    async install() {
      const outcome = await promptInstall();
      if (outcome === 'accepted') dismissWelcome();
    },
  };

  const offClick = on(root, 'click', '[data-action]', (_, btn) => actions[btn.dataset.action]?.());
  holdToConfirm(el('hold'), HOLD_MS, () => {
    haptic([20, 60, 20]);
    resetRitual();
    applyState('idle');
    announce('Ritual ended early.');
    toast('Ritual ended early. Come back whenever you’re ready.');
  });

  // Length picker on the home screen (mirrors Settings)

  const offLength = on(root, 'change', 'input[name="home-length"]', (_, input) => {
    updateSettings({ lengthMin: Number(input.value) });
  });

  // Welcome

  function dismissWelcome() {
    store.set({ welcome: { dismissed: true } });
    const card = el('welcome');
    if (!card) return;
    const hadFocus = card.contains(document.activeElement);
    card.remove();
    if (hadFocus) qs('[data-action="begin"]', root)?.focus();
  }
  const offInstall = onInstallAvailability((available) => {
    const btn = el('install-btn');
    if (btn) btn.hidden = !available;
  });

  // Ambience

  const volumeInput = el('volume');
  ambient.setVolume(Number(volumeInput.value));
  ambient.setLayerVolumes(store.get().settings.volumes);

  const syncTiles = (playing) => {
    qsa('[data-sound]', root).forEach((tile) => {
      tile.setAttribute('aria-pressed', String(playing.has(tile.dataset.sound)));
    });
    el('volume-wrap').hidden = playing.size === 0;
  };
  syncTiles(new Set(ambient.SOUND_LIST.map((s) => s.id).filter(ambient.isPlaying)));

  const offTiles = on(root, 'click', '[data-sound]', (_, tile) => ambient.toggle(tile.dataset.sound));
  const offAmbient = ambient.onChange(syncTiles);
  volumeInput.addEventListener('input', () => ambient.setVolume(Number(volumeInput.value)));
  volumeInput.addEventListener('change', () => store.set({ ambient: { volume: Number(volumeInput.value) } }));

  // Mind dump journal

  const journal = el('journal');
  const journalMetaEl = el('journal-meta');
  let saveTimer = null;

  const autosize = () => {
    journal.style.height = 'auto';
    journal.style.height = `${journal.scrollHeight}px`;
  };

  const showJournalState = () => {
    journalMetaEl.textContent = journalMeta(journal.value, store.get().settings.keepNotes);
    qsa('[data-needs-text]', root).forEach((btn) => { btn.disabled = !journal.value; });
  };

  const saveJournal = () => {
    clearTimeout(saveTimer);
    saveTimer = null;
    store.set(({ journal: saved, prompts }) => ({
      journal: {
        ...saved,
        text: journal.value,
        updatedAt: Date.now(),
        // A page keeps the date it was started on. (v1.0 re-dated it on every save, so a page
        // begun before midnight and finished after it escaped the next launch's catch-up clear.)
        day: saved.text && saved.day ? saved.day : dayKey(),
        promptId: saved.text && saved.promptId ? saved.promptId : prompts.current,
      },
    }));
    showJournalState();
  };

  // The midnight reset clears the store; drop the on-screen draft and any pending save with it.
  let seenReset = store.get().journal.resetAt;
  const offReset = store.subscribe(({ journal: saved, archive }) => {
    const link = el('archive-link');
    const showLink = store.get().settings.keepNotes || archive.length > 0;
    link.hidden = !showLink;
    link.textContent = archiveLabel(archive.length);
    if (saved.resetAt === seenReset) return;
    seenReset = saved.resetAt;
    clearTimeout(saveTimer);
    saveTimer = null;
    journal.value = '';
    autosize();
    showJournalState();
  });

  // Settings changed elsewhere (sheet or home picker): keep this screen in step.
  let seenSettings = store.get().settings;
  const offSettings = store.subscribe(({ settings, ritual }) => {
    if (settings === seenSettings) return;
    seenSettings = settings;
    ambient.setLayerVolumes(settings.volumes);
    const radio = qs(`input[name="home-length"][value="${settings.lengthMin}"]`, root);
    if (radio && !radio.checked) radio.checked = true;
    if (ritual.status === 'idle') paint(remainingMs());
    if (!saveTimer) showJournalState();
  });

  journal.addEventListener('input', () => {
    autosize();
    journalMetaEl.textContent = journalMeta(journal.value, false, true);
    qsa('[data-needs-text]', root).forEach((btn) => { btn.disabled = !journal.value; });
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveJournal, 500);
  });
  journal.addEventListener('blur', () => { if (saveTimer) saveJournal(); });

  const currentPage = () => {
    if (saveTimer) saveJournal();
    return formatPage(pageFromJournal(store.get().journal));
  };

  async function copyJournal() {
    if (!journal.value.trim()) return;
    const ok = await copyText(currentPage());
    toast(ok ? 'Copied. Paste it anywhere you like to keep it.' : 'Couldn’t copy here. Try Save .txt instead.');
  }

  async function saveJournalTxt() {
    if (!journal.value.trim()) return;
    const result = await saveTextFile(currentPage(), fileName(store.get().journal.day ?? dayKey()));
    if (result === 'downloaded') toast('Saved as a .txt file in your downloads.');
    else if (result === 'shared') toast('Saved.');
  }

  function releaseJournal() {
    const previous = journal.value;
    journal.classList.add('journal--release');
    setTimeout(() => {
      journal.value = '';
      journal.classList.remove('journal--release');
      saveJournal();
      autosize();
    }, 450);
    toast('Released. Let it go.', {
      action: 'Undo',
      duration: 6000,
      onAction: () => {
        journal.value = previous;
        saveJournal();
        autosize();
      },
    });
  }

  // Save-on-exit: flush the draft and remember where the user was.

  const saveSession = () => {
    if (saveTimer) saveJournal();
    store.set({
      session: {
        day: dayKey(),
        scrollY: Math.round(window.scrollY),
        sounds: ambient.SOUND_LIST.map((s) => s.id).filter(ambient.isPlaying),
      },
    });
  };
  const offSuspend = onSuspend(saveSession);

  function restoreSession() {
    const { session } = store.get();
    if (session.day !== clock.today()) return; // a new day starts at the top, in silence
    // After the router's own scroll-to-top.
    requestAnimationFrame(() => window.scrollTo(0, session.scrollY));
    const sounds = session.sounds.filter((id) => !ambient.isPlaying(id));
    if (sounds.length) {
      // Browsers only allow audio to start from a tap, so offer it rather than autoplay.
      const names = ambient.SOUND_LIST.filter((s) => sounds.includes(s.id)).map((s) => s.label).join(' + ');
      toast(`Pick up where you left off? ${names}`, {
        action: 'Play',
        duration: 10000,
        onAction: () => sounds.forEach(ambient.play),
      });
    }
  }

  requestAnimationFrame(autosize);
  applyState(getRitual().status);
  restoreSession();

  return () => {
    saveSession();
    releaseLock?.();
    releaseAwake();
    stopWatch?.();
    offClick();
    offTiles();
    offAmbient();
    offReset();
    offSettings();
    offSuspend();
    offMinute();
    offLength();
    offInstall();
  };
}

/** Press-and-hold confirmation for pointer and keyboard (Space / Enter). */
function holdToConfirm(button, ms, onConfirm) {
  let timer = null;

  const start = () => {
    if (timer) return;
    button.dataset.holding = '';
    button.style.setProperty('--hold-ms', `${ms}ms`);
    haptic(8);
    timer = setTimeout(() => {
      cancel();
      onConfirm();
    }, ms);
  };
  const cancel = () => {
    clearTimeout(timer);
    timer = null;
    delete button.dataset.holding;
  };

  button.addEventListener('pointerdown', (e) => {
    if (e.button === 0) start();
  });
  ['pointerup', 'pointerleave', 'pointercancel', 'blur'].forEach((type) => button.addEventListener(type, cancel));
  button.addEventListener('contextmenu', (e) => e.preventDefault());
  button.addEventListener('keydown', (e) => {
    if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) {
      e.preventDefault();
      start();
    }
  });
  button.addEventListener('keyup', (e) => {
    if (e.key === ' ' || e.key === 'Enter') cancel();
  });
}

