import { html, render, qs, on } from '../core/dom.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { ARCHIVE_NIGHTS } from '../features/journal-reset.js';
import { copyText, fileName, formatPage, saveTextFile } from '../features/journal-export.js';

export const title = 'Saved nights';

const longDate = (day) => {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
};

function intro(keepNotes) {
  return keepNotes
    ? `Your last ${ARCHIVE_NIGHTS} nights, kept on this device only. Older nights drop off on their own.`
    : '“Keep my notes” is off, so new nights aren’t being saved. These stay until you delete them.';
}

function template({ archive, settings }) {
  return html`
    <section class="archive stack-lg stack fade-in">
      <header class="stack stack-sm">
        <a class="link-btn back-link" href="#/">← Back to tonight</a>
        <h1 tabindex="-1">Saved nights</h1>
        <p class="text-muted" data-el="intro">${intro(settings.keepNotes)}</p>
      </header>

      ${archive.length === 0
        ? html`<p class="archive__empty">Nothing saved yet. With “Keep my notes” on, each night’s mind dump is filed here at midnight instead of disappearing.</p>`
        : html`<ol class="archive__list">
            ${archive.map((night, i) => html`
              <li class="night" aria-labelledby="night-${i}">
                <h2 class="night__date" id="night-${i}">${longDate(night.day)}</h2>
                ${night.prompt ? html`<p class="night__prompt">${night.prompt}</p>` : ''}
                <p class="night__text">${night.text}</p>
                <div class="night__actions">
                  <button class="link-btn" type="button" data-action="copy" data-index="${i}">Copy</button>
                  <button class="link-btn" type="button" data-action="save" data-index="${i}">Save .txt</button>
                </div>
              </li>`)}
          </ol>`}

      ${archive.length ? html`
        <div class="danger-zone" data-el="delete-zone">
          <button class="btn btn--ghost btn--danger-ghost" type="button" data-action="delete-ask" data-el="delete-ask">Delete all saved nights</button>
          <div class="confirm" data-el="delete-confirm" role="group" aria-labelledby="delete-q" hidden>
            <p id="delete-q">Delete ${archive.length} saved ${archive.length === 1 ? 'night' : 'nights'} from this device? This can’t be undone.</p>
            <div class="row">
              <button class="btn btn--ghost" type="button" data-action="delete-cancel">Keep them</button>
              <button class="btn btn--danger" type="button" data-action="delete-confirm">Delete</button>
            </div>
          </div>
        </div>` : ''}
    </section>
  `;
}

export function mount(root) {
  const draw = () => render(root, template(store.get()));
  draw();
  const el = (name) => qs(`[data-el="${name}"]`, root);
  const page = (i) => {
    const night = store.get().archive[Number(i)];
    return night && { night, text: formatPage({ text: night.text, day: night.day, prompt: night.prompt }) };
  };

  const actions = {
    async copy(btn) {
      const p = page(btn.dataset.index);
      if (p) toast((await copyText(p.text)) ? 'Copied.' : 'Couldn’t copy here. Try Save .txt instead.');
    },
    async save(btn) {
      const p = page(btn.dataset.index);
      if (p && (await saveTextFile(p.text, fileName(p.night.day))) === 'downloaded') toast('Saved as a .txt file in your downloads.');
    },
    'delete-ask'() {
      el('delete-ask').hidden = true;
      el('delete-confirm').hidden = false;
      qs('[data-action="delete-cancel"]', root).focus();
    },
    'delete-cancel'() {
      el('delete-confirm').hidden = true;
      el('delete-ask').hidden = false;
      el('delete-ask').focus();
    },
    'delete-confirm'() {
      store.set({ archive: [] });
      toast('Saved nights deleted.');
      qs('h1', root)?.focus();
    },
  };

  const off = on(root, 'click', '[data-action]', (_, btn) => actions[btn.dataset.action]?.(btn));
  // Redraw if the archive changes underneath us (e.g. the midnight clear files a new night).
  let seen = store.get().archive;
  const offStore = store.subscribe(({ archive }) => {
    if (archive === seen) return;
    seen = archive;
    draw();
  });
  return () => {
    off();
    offStore();
  };
}
