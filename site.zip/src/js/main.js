import { createRouter } from './core/router.js';
import { registerServiceWorker } from './core/sw-register.js';
import { installAudioUnlock } from './features/ambient.js';
import { captureInstallPrompt } from './features/install.js';
import { startJournalReset } from './features/journal-reset.js';

// Views load lazily so first paint only pays for the screen being shown.
const routes = {
  '/': () => import('./views/ritual.js'),
  '/archive': () => import('./views/archive.js'),
};

const router = createRouter({
  root: document.getElementById('view'),
  routes,
  notFound: () => import('./views/not-found.js'),
});

// Before anything else: iOS only lets audio start inside the first tap.
installAudioUnlock();
captureInstallPrompt();

const settingsButton = document.querySelector('[data-open-settings]');
settingsButton?.addEventListener('click', async () => {
  const { openSettings } = await import('./views/settings-sheet.js');
  openSettings(settingsButton);
});

startJournalReset();
router.start();
registerServiceWorker();
