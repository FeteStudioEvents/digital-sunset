import { html, render } from './dom.js';

/**
 * Shows a single toast at a time. Pass `duration: 0` to keep it until dismissed.
 * Returns a dismiss function.
 */
export function toast(message, { action, onAction, duration = 5000 } = {}) {
  document.querySelector('.toast')?.remove();

  const el = document.createElement('div');
  el.className = 'toast';
  el.setAttribute('role', 'status');
  render(el, html`<span>${message}</span>${action ? html`<button class="btn" type="button">${action}</button>` : ''}`);

  let timer = null;
  const dismiss = () => {
    clearTimeout(timer);
    el.classList.add('toast--out');
    setTimeout(() => el.remove(), 300);
  };

  el.querySelector('button')?.addEventListener('click', () => {
    onAction?.();
    dismiss();
  });

  document.body.append(el);
  if (duration) timer = setTimeout(dismiss, duration);
  return dismiss;
}
