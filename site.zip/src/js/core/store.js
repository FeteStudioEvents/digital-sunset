/**
 * Tiny observable store persisted to localStorage.
 * State never leaves the device — no network, no accounts.
 */
export const STORAGE_PREFIX = 'fete:';

export function createStore(key, initial) {
  let state = load(key, initial);
  let frozen = false;
  const listeners = new Set();

  return {
    get: () => state,
    set(update) {
      const next = typeof update === 'function' ? update(state) : update;
      state = { ...state, ...next };
      if (!frozen) persist(key, state);
      listeners.forEach((fn) => fn(state));
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    reset() {
      state = structuredClone(initial);
      persist(key, state);
      listeners.forEach((fn) => fn(state));
    },
    /**
     * Erases everything this app saved and stops persisting until the page reloads,
     * so a save-on-exit handler running during the reload can't write the old data back.
     */
    wipe() {
      frozen = true;
      state = structuredClone(initial);
      try {
        Object.keys(localStorage)
          .filter((k) => k === key || k.startsWith(`${key}:`)) // only this app's data; other Fête apps share the origin
          .forEach((k) => localStorage.removeItem(k));
      } catch {
        // Storage blocked — nothing was saved anyway.
      }
    },
  };
}

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/**
 * Fills in fields added since the data was saved, at every depth, so a v1.0 save
 * (no ritual.durationMs, no settings) loads cleanly into the v1.1 shape.
 */
function withDefaults(defaults, saved) {
  if (!isPlainObject(defaults) || !isPlainObject(saved)) return saved === undefined ? structuredClone(defaults) : saved;
  const out = { ...structuredClone(defaults), ...saved };
  for (const k of Object.keys(defaults)) {
    if (isPlainObject(defaults[k])) out[k] = withDefaults(defaults[k], saved[k]);
  }
  return out;
}

function load(key, initial) {
  try {
    const saved = localStorage.getItem(key);
    if (!saved) return structuredClone(initial);
    return { ...withDefaults(initial, JSON.parse(saved)), version: initial.version };
  } catch {
    return structuredClone(initial);
  }
}

function persist(key, state) {
  try {
    localStorage.setItem(key, JSON.stringify(state));
  } catch {
    // Storage full or blocked (private mode) — keep working in memory.
  }
}

export const LENGTHS = [30, 45, 60];

/** App-wide store. Add fields here as features land; bump `version` on breaking shape changes. */
export const store = createStore(`${STORAGE_PREFIX}selfcare`, {
  version: 4,
  name: '',
  ritual: { status: 'idle', startedAt: null, endsAt: null, durationMs: 60 * 60 * 1000, returns: 0 },
  ambient: { volume: 0.7 },
  journal: { text: '', updatedAt: null, day: null, resetAt: null, promptId: null },
  // Where the user left off, written when the app is hidden or closed.
  session: { day: null, scrollY: 0, sounds: [] },
  settings: {
    lengthMin: 60,
    volumes: { brown: 0.7, rain: 0.7, cabin: 0.7 },
    haptics: true,
    keepNotes: false,
  },
  // Shuffled prompt cycle: `order` is a permutation of prompt ids, `pos` the next unused slot.
  prompts: { order: [], pos: 0, night: null, current: null, swaps: 0 },
  // Kept nights (only when settings.keepNotes is on): newest first, at most 14.
  archive: [],
  welcome: { dismissed: false },
});

/** Merges a patch into settings (store.set only merges the top level). */
export function updateSettings(patch) {
  store.set(({ settings }) => ({ settings: { ...settings, ...patch } }));
}
