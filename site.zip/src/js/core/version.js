/** Product version, shown in Settings → About. Keep in step with sw.js VERSION notes and CHANGELOG.md. */
export const APP_VERSION = '1.1.0';
