/**
 * Local wall-clock tracker.
 *
 * Ticks on every minute boundary and emits `day` whenever the local calendar
 * date changes. Browsers throttle or freeze timers in background tabs, so the
 * date is also re-checked whenever the app becomes visible again — a day that
 * rolled over while the phone was locked is reported on return.
 * A device timezone change shows up as a new local date in the same way.
 */

/** Local calendar date as "YYYY-MM-DD" (not UTC). */
export function dayKey(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function msUntilMidnight(now = new Date()) {
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  return midnight - now;
}

const msUntilNextMinute = (now = new Date()) => 60_000 - (now.getSeconds() * 1000 + now.getMilliseconds());

const listeners = { minute: new Set(), day: new Set() };
let currentDay = dayKey();
let timer = null;

function check() {
  const now = new Date();
  listeners.minute.forEach((fn) => fn(now));
  const today = dayKey(now);
  if (today !== currentDay) {
    const previous = currentDay;
    currentDay = today;
    listeners.day.forEach((fn) => fn(today, previous));
  }
}

function schedule() {
  clearTimeout(timer);
  // A small margin keeps the tick from landing a hair before the boundary.
  timer = setTimeout(() => {
    check();
    schedule();
  }, msUntilNextMinute() + 50);
}

function onResume() {
  if (document.visibilityState !== 'visible') return;
  check();
  schedule();
}

function start() {
  currentDay = dayKey();
  schedule();
  document.addEventListener('visibilitychange', onResume);
  window.addEventListener('pageshow', onResume);
  window.addEventListener('focus', onResume);
}

function stop() {
  clearTimeout(timer);
  timer = null;
  document.removeEventListener('visibilitychange', onResume);
  window.removeEventListener('pageshow', onResume);
  window.removeEventListener('focus', onResume);
}

function subscribe(kind, fn) {
  const wasIdle = listeners.minute.size + listeners.day.size === 0;
  listeners[kind].add(fn);
  if (wasIdle) start();
  return () => {
    listeners[kind].delete(fn);
    if (listeners.minute.size + listeners.day.size === 0) stop();
  };
}

export const clock = {
  today: () => currentDay,
  /** fn(now) at every local minute boundary. */
  onMinute: (fn) => subscribe('minute', fn),
  /** fn(today, previousDay) when the local date changes, e.g. at midnight. */
  onDayChange: (fn) => subscribe('day', fn),
};
