/**
 * Save-on-exit hook.
 *
 * Mobile browsers rarely fire `beforeunload`/`unload` when an app is swiped
 * away. The reliable signals are `visibilitychange → hidden` (fires on app
 * switch, lock screen, and before close) and `pagehide`, so handlers run on
 * both. They must be synchronous: anything async may never finish.
 */
const handlers = new Set();

function flush() {
  handlers.forEach((fn) => {
    try {
      fn();
    } catch (err) {
      console.warn('[session] save failed', err);
    }
  });
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') flush();
});
window.addEventListener('pagehide', flush);

/** Registers a synchronous save handler. Returns an unsubscribe function. */
export function onSuspend(fn) {
  handlers.add(fn);
  return () => handlers.delete(fn);
}
